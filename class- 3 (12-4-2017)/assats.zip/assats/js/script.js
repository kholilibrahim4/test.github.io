(function() {
  'use strict';
    
    $(document).ready(function() {
      $('.magnific-video').magnificPopup({type:'video'});
    });
    
})();
